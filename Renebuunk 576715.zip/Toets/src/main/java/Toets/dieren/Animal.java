package Toets.dieren;

public class Animal{

    public String name;

    public Animal(String name) {
        this.name = name;
    }
}
